-- CreateTable
CREATE TABLE "cartao" (
    "id" TEXT NOT NULL,
    "nomeTitular" TEXT NOT NULL,
    "numCartao" TEXT NOT NULL,
    "cvv" TEXT NOT NULL,
    "senha" TEXT NOT NULL,

    CONSTRAINT "cartao_pkey" PRIMARY KEY ("id")
);
