import { hash } from "bcryptjs";
import p from "../../../prisma";


interface CartaoRequest {
  nomeTitular: string;
  numCartao: string;
  cvv: string;
  senha: string;
}

class CreateCartaoService {
  async execute({ nomeTitular, numCartao, cvv, senha }: CartaoRequest) {
    const senhaHash = await hash(senha, 8);
    const cvvHash = await hash(cvv, 8);

    const cartao = await p.cartao.create({
      data: {
        nomeTitular: nomeTitular,
        numCartao: numCartao,
        cvv: cvvHash,
        senha: senhaHash,
      },
      select: {
        id: true,
        numCartao: true,
        cvv: true,
      },
    });

    return cartao;
  }
}

export { CreateCartaoService };
