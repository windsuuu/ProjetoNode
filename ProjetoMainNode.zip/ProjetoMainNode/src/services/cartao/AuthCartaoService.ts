import { compare } from "bcryptjs";
import { sign } from "jsonwebtoken";
import p from "../../../prisma";
import env from "../../variables";


interface AuthRequest {
  numCartao: string;
  cvv: string;
}

class AuthCartaoService {
  async execute({ numCartao, cvv }: AuthRequest) {
    const cartao = await p.cartao.findFirst({
      where: {
        numCartao: numCartao,
      },
    });

    if (!cartao) {
      throw new Error("Usuário ou cvv incorretos!");
    }

    const cvvMatch = await compare(cvv, cartao.cvv);

    if (!cvvMatch) {
      throw new Error("cvv incorreto!");
    }

    const token = sign(
      {
        numCartao: cartao.numCartao,
        cvv: cartao.cvv,
      },
      env.JWT_SECRET,
      {
        subject: cartao.id,
        expiresIn: "30d",
      }
    );

    return {
      id: cartao.id,
      numCartao: cartao.numCartao,
      cvv: cartao.cvv,
      token: token,
    };
  }
}

export { AuthCartaoService };
