import { Router } from "express";
import { isAuthenticated } from "./middlewares/isAuthenticated";
import { AuthCartaoController } from "./controllers/cartao/AuthCartaoController";
import { CreateCartaoController } from "./controllers/cartao/CreateCartaoController";
import { DetailCartaoController } from "./controllers/cartao/DetailCartaoController";


const router = Router();

router.post("/clienteCartao", new CreateCartaoController().handle);
router.post("/authCartao", new AuthCartaoController().handle);
router.get(
  "/tokenCartao",
  isAuthenticated,
  new DetailCartaoController().handle
);

export { router };
