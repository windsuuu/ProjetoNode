import { Request, Response } from "express";
import { CreateCartaoService } from "../../services/cartao/CreateCartaoService";


class CreateCartaoController {
  async handle(req: Request, res: Response) {
    const { nomeTitular, numCartao, cvv, senha } = req.body;

    const createCartaoService = new CreateCartaoService();
    const cartao = await createCartaoService.execute({
      nomeTitular,
      numCartao,
      cvv,
      senha,
    });

    return res.json(cartao);
  }
}

export { CreateCartaoController };
