import { Request, Response } from "express";
import { AuthCartaoService } from "../../services/cartao/AuthCartaoService";


class AuthCartaoController {
  async handle(req: Request, res: Response) {
    const { numCartao, cvv } = req.body;

    const authCartaoService = new AuthCartaoService();

    const auth = await authCartaoService.execute({
      numCartao,
      cvv,
    });

    return res.json(auth);
  }
}

export { AuthCartaoController };